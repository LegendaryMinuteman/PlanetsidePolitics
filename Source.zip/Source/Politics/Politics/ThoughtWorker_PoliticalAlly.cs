﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace Politics
{
    class ThoughtWorker_PoliticalAlly : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn thisPawn, Pawn thatPawn)
        {
            if (!thisPawn.RaceProps.Humanlike)
                return (ThoughtState)false;
            if (!RelationsUtility.PawnsKnowEachOther(thisPawn, thatPawn))
                return (ThoughtState)false;
            if (thatPawn.def != thisPawn.def)
                return (ThoughtState)false;
            if (!thisPawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                return (ThoughtState)false;
            TraitDef samePolitics = thisPawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait).def;
            if (thatPawn.story.traits.HasTrait(samePolitics))
                return (ThoughtState)true;
            return (ThoughtState)false;
        }
    }
}