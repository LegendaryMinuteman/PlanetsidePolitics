﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace Politics
{
    class TraitDef_PoliticsTrait : TraitDef
    {
        public List<TraitDef> PoliticalAlly = new List<TraitDef>();
        public List<TraitDef> PoliticalAdjacent = new List<TraitDef>();
        public List<TraitDef> PoliticalMisguided = new List<TraitDef>();
        public List<TraitDef> PoliticalRivalry = new List<TraitDef>();
        public List<TraitDef> PoliticalEnemy = new List<TraitDef>();
        public bool isTribalIdeology;
        public bool isPirateIdeology;
    }
}