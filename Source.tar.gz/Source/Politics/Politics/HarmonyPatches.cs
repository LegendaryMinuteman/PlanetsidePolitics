﻿using Harmony;
using RimWorld;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Verse;

namespace Politics
{
    [StaticConstructorOnStartup] // Special thank you to Mehdi and LWM at Ludeon Studios forum (https://wwww.ludeon.com/forum) for helping me develop this code.
    internal static class HarmonyPatches

    {
        private static HarmonyInstance harmony = HarmonyInstance.Create("PoliticsMod");

        static HarmonyPatches()
        {
            HarmonyPatches.harmony.PatchAll(Assembly.GetExecutingAssembly());
        }

        [HarmonyPatch(typeof(TraitSet), "GainTrait")]
        private static class Patch_GainTrait
        {
            [HarmonyPriority(Priority.First)]
            private static bool Prefix(TraitSet __instance, Pawn ___pawn, Trait trait)
            {

                if (trait.def is TraitDef_PoliticsTrait)
                    {
                        TraitDef_PoliticsTrait traitPoliticsTrait = trait.def as TraitDef_PoliticsTrait;
                        if (traitPoliticsTrait.isTribalIdeology == false)
                        {
                            if (___pawn.Faction.def.techLevel == RimWorld.TechLevel.Neolithic)
                            {
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        else if (traitPoliticsTrait.isPirateIdeology == false)
                        {
                            if (___pawn.Faction.def.defName == "Pirate")
                            {
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                else
                {
                    return true;
                }

            }

        }

    }

}