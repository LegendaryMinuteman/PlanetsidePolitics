﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse.AI;
using Verse;

namespace Politics
{
    class MentalBreakWorker_ChangePolitics : MentalBreakWorker
    {
        public override float CommonalityFor(Pawn pawn)
        {
            float baseCommonality = this.def.baseCommonality;
            if (pawn.Faction == Faction.OfPlayer && this.def.commonalityFactorPerPopulationCurve != null)
                baseCommonality *= this.def.commonalityFactorPerPopulationCurve.Evaluate((float)PawnsFinder.AllMaps_FreeColonists.Count<Pawn>());
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                return 0;
            return baseCommonality;
        }

        public override bool TryStart(Pawn pawn, string reason, bool causedByMood)
        {
            Random rn = new Random();
            int chance = rn.Next(1, 20);
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
            {
                Trait oldIdeology = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait);
                pawn.story.traits.allTraits.Remove(oldIdeology);
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Add(new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait && x.defName != oldIdeology.def.defName).RandomElement()));
                }
                return base.TryStart(pawn, reason, causedByMood);
            }
            else
            {
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Add(new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait).RandomElement()));
                }
                return base.TryStart(pawn, reason, causedByMood);
            }
        }
    }
}
