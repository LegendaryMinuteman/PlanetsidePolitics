﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using Verse.AI;
using RimWorld;

namespace Politics
{
    public class CompUseEffect_SetPolitics : CompUseEffect
    {
        public override void DoEffect(Pawn user)
        {
            Random rn = new Random();
            int intCheck = rn.Next(1, 15);
            SkillDef intellectual = SkillDefOf.Intellectual;
            int intellect = user.skills.GetSkill(intellectual).Level;
            this.parent.TryGetQuality(out QualityCategory qc); // Thanks LWM at Ludeon Forums for elucidating this for me.
            int qualityInt = 0;
            string qualityString = "null";
            if (qc == QualityCategory.Awful)
            {
                qualityInt = -5;
                qualityString = "awful";
            }
            else if (qc == QualityCategory.Poor)
            {
                qualityInt = -3;
                qualityString = "poor";
            }
            else if (qc == QualityCategory.Normal)
            {
                qualityInt = 0;
                qualityString = "normal";
            }
            else if (qc == QualityCategory.Good)
            {
                qualityInt = 1;
                qualityString = "good";
            }
            else if (qc == QualityCategory.Excellent)
            {
                qualityInt = 2;
                qualityString = "excellent";
            }
            else if (qc == QualityCategory.Masterwork)
            {
                qualityInt = 3;
                qualityString = "masterwork";
            }
            else if (qc == QualityCategory.Legendary)
            {
                qualityInt = 5;
                qualityString = "legendary";
            }
            // everything comes together for the final check
            if (intCheck + qualityInt >= intellect)
            {
                ThingDef polemic = this.parent.def;
                Trait newIdeology = new Trait();
                if (polemic.defName == "Politics_Book_Anarchy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsAnarchist"));
                }
                else if (polemic.defName == "Politics_Book_Despotism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsDespot"));
                }
                else if (polemic.defName == "Politics_Book_Monarchy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsMonarchist"));
                }
                else if (polemic.defName == "Politics_Book_Theocracy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsTheocrat"));
                }
                else if (polemic.defName == "Politics_Book_Socialism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsSocialist"));
                }
                else if (polemic.defName == "Politics_Book_Communism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsCommunist"));
                }
                else if (polemic.defName == "Politics_Book_Fascism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsFascist"));
                }
                else if (polemic.defName == "Politics_Book_Democracy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsDemocrat"));
                }
                else if (polemic.defName == "Politics_Book_Republic")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsRepublican"));
                }
                if (user.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                {
                    Trait oldIdeology = user.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait);
                    user.story.traits.allTraits.Remove(oldIdeology);
                }
                string success = user.Name.ToString() + " found the " + qualityString + " polemic very compelling.";
                user.story.traits.allTraits.Add(newIdeology);
                Messages.Message(success, MessageTypeDefOf.PositiveEvent);
            }
            else
            {
                string fail = user.Name.ToString() + " found the " + qualityString + " polemic unconvincing.";
                Messages.Message(fail, MessageTypeDefOf.NegativeEvent);
            }
        }
    }
}